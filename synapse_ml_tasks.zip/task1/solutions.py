from itertools import combinations
from collections import Counter

def strongest_teams(pokedex, k):
    names = list(pokedex.keys())
    best = []
    max_count = -1
    for team in combinations(names, k):
        types = set()
        for nm in team:
            types.update(pokedex[nm])
        c = len(types)
        if c > max_count:
            max_count = c
            best = [(team, types)]
        elif c == max_count:
            best.append((team, types))
    return max_count, best

def earliest_step_for_LUMOS(runes):
    needed = set("LUMOS")
    cnt = Counter()
    for i, ch in enumerate(runes, start=1):
        cnt[ch.upper()] += 1
        if all(cnt[c] >= 1 for c in needed):
            return i
    return -1

def best_bomb_spots(grid, m):
    n = len(grid)
    grid_bottom = grid[::-1]
    ps = [[0]*(n+1) for _ in range(n+1)]
    for y in range(n):
        for x in range(n):
            ps[y+1][x+1] = grid_bottom[y][x] + ps[y][x+1] + ps[y+1][x] - ps[y][x]
    half = m // 2
    best_coords = []
    max_count = -1
    for y in range(half, n-half):
        for x in range(half, n-half):
            if grid_bottom[y][x] != 1:
                continue
            y1, x1 = y-half, x-half
            y2, x2 = y+half, x+half
            total = ps[y2+1][x2+1] - ps[y1][x2+1] - ps[y2+1][x1] + ps[y1][x1]
            if total > max_count:
                max_count = total
                best_coords = [(x, y)]
            elif total == max_count:
                best_coords.append((x, y))
    return max_count, best_coords

if __name__ == "__main__":
    pokedex = {
        'Pikachu': ('Electric',),
        'Charizard': ('Fire', 'Flying'),
        "Lapras": ("Water", "Ice"),
        "Machamp": ("Fighting",),
        "Mewtwo": ("Psychic", "Fighting"),
        "Hoopa": ("Psychic", "Ghost", "Dark"),
        "Lugia": ("Psychic", "Flying", "Water"),
        "Squirtle": ("Water",),
        "Gengar": ("Ghost", "Poison"),
        "Onix": ("Rock", "Ground")
    }
    print("Task 1.1: Strongest Teams")
    max_types, teams = strongest_teams(pokedex, 3)
    print("Max distinct types:", max_types)
    for team, types in teams:
        print("Team:", team, "Types:", types)

    print("\nTask 1.2: Hermione Spell")
    runes = "LMUOSXYZ"
    print("Earliest step:", earliest_step_for_LUMOS(runes))

    print("\nTask 1.3: Bombing")
    grid = [
        [1,0,0,0,1],
        [1,0,1,1,1],
        [1,1,0,1,1],
        [1,0,1,1,0],
        [0,1,0,1,1]
    ]
    print(best_bomb_spots(grid, 3))
