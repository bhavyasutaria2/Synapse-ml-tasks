# Synapse ML Tasks

This repository contains solutions for Task 1 (Basic Python) and Task 2 (EDA).

## Task 1 - Basic Python
File: `task1/solutions.py`

Contains solutions for:
- Pokémon Strongest Team
- Hermione's Spell
- Bombing the Region

Run:
```bash
python task1/solutions.py
```

## Task 2 - EDA
File: `task2/eda_notebook.ipynb`

Example notebook demonstrating exploratory data analysis (EDA) using Pandas, NumPy, Matplotlib, and Seaborn.

Open with Jupyter or Kaggle to run and visualize results.
